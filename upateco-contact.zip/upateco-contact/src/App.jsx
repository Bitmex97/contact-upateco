import { useRef, useState } from 'react';
import emailjs from '@emailjs/browser';
import './App.css';

function App() {
  const form = useRef();
  const [status, setStatus] = useState('');

  const sendEmail = (e) => {
    e.preventDefault();
    setStatus('enviando');

    emailjs
      .sendForm(
        import.meta.env.VITE_EMAILJS_SERVICE_ID,
        import.meta.env.VITE_EMAILJS_TEMPLATE_ID,
        form.current,
        import.meta.env.VITE_EMAILJS_PUBLIC_KEY
      )
      .then(() => {
        setStatus('exito');
        form.current.reset();
      })
      .catch((error) => {
        console.error('Error EmailJS:', error);
        setStatus('error');
      });
  };

  return (
    <div className="container">
      <header>
        <h1>Contacto UPATECO</h1>
        <p>Universidad Provincial de Administración, Tecnología y Oficios</p>
      </header>

      <div className="content-grid">
        {/* Formulario */}
        <section className="form-section">
          <h2>Envíanos un mensaje</h2>
          <form ref={form} onSubmit={sendEmail} className="contact-form">
            <div className="field">
              <label htmlFor="name">Nombre</label>
              <input type="text" id="name" name="name" required placeholder="Tu nombre" />
            </div>

            <div className="field">
              <label htmlFor="email">Correo electrónico</label>
              <input type="email" id="email" name="email" required placeholder="tu@correo.com" />
            </div>

            <div className="field">
              <label htmlFor="message">Mensaje</label>
              <textarea id="message" name="message" rows="5" required placeholder="Escribe tu mensaje aquí..."></textarea>
            </div>

            <button type="submit" disabled={status === 'enviando'}>
              {status === 'enviando' ? 'Enviando...' : 'Enviar mensaje'}
            </button>

            {status === 'exito' && <p className="feedback success">Mensaje enviado correctamente.</p>}
            {status === 'error' && <p className="feedback error">Hubo un error al enviar. Intenta nuevamente.</p>}
          </form>
        </section>

        {/* Mapa */}
        <section className="map-section">
          <h2>Nuestra ubicación</h2>
          <div className="map-wrapper">
            {/* REEMPLAZA EL SRC DE ABAJO POR EL TUYO DE GOOGLE MAPS */}
            <iframe
              title="Ubicación UPATECO"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3622.5!2d-65.4!3d-24.8!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjTCsDQ4JzAwLjAiUyA2NcKwMjQnMDAuMCJX!5e0!3m2!1ses!2sar!4v1700000000000"
              width="100%"
              height="400"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
            ></iframe>
          </div>
          <p className="address">Ciudad Educativa, Av. Constitución Nacional s/n, Bº Pereyra Rozas, Salta</p>
        </section>
      </div>
    </div>
  );
}

export default App;